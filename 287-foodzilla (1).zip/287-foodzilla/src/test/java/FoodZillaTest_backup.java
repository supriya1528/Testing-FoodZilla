package org.example;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.*;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;


import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.MobileElement;
import junit.framework.Assert;



@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class FoodZillaTest_backup {
	AndroidDriver<AndroidElement> driver;

	@Before
	public void setUp() throws MalformedURLException {

		System.out.println("Running Automated Test cases on FOODZILLA AI Mobile Application");
		DesiredCapabilities dc = new DesiredCapabilities();
		dc.setCapability(MobileCapabilityType.AUTOMATION_NAME, "UiAutomator2");
		dc.setCapability("platformName", "Android");
		dc.setCapability("udid", "25e8fa1cd30d7ece"); //26b96abf
		dc.setCapability(MobileCapabilityType.DEVICE_NAME, "SM-N960F");
		dc.setCapability("appPackage", "io.foodzilla.app");
		dc.setCapability("appActivity", "io.foodzilla.app.MainActivity");
		dc.setCapability("noReset", "true");
		URL url = new URL("http://127.0.0.1:4723/wd/hub");
		driver = new AndroidDriver<AndroidElement>(url, dc);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

	}

	boolean askLogin = true;
	//boolean askLogin = false;

	@Test
	public void Login() {

		try {
			driver.findElementByXPath("//android.widget.TextView[@text='Log in (for invited users)']").isDisplayed();
		} catch (Exception e) {
			askLogin = false;
		}

		if (askLogin) {
			System.out.println("Login Required");
			System.out.println("About to click on loggin button");
			String loginInvitedUser = "//android.widget.TextView[@text='Log in (for invited users)']";
			clickElement(loginInvitedUser);
			System.out.println("clicked on login button");
			String enterEmailLocator = "//android.widget.EditText[@text='Enter email']";
			enterText(enterEmailLocator, "nehithyadav02@gmail.com");
			String enterPasswordLocator = "//android.widget.EditText[@text='Enter password']";
			enterText(enterPasswordLocator, "Foodzilla");
			String continueButton = "//android.widget.TextView[@text='Continue']";
			clickElement(continueButton);
			System.out.println("clicked on continue button");

		} else {
			System.out.println("Didn't ask for login");
		}

	}


	public void clickElement(String xpathString) {
		driver.findElementByXPath(xpathString).click();
		System.out.println("The element got clicked");

	}

	public void enterText(String xpathString, String value) {
		driver.findElementByXPath(xpathString).sendKeys(value);
	}

	public String getText(String xpathString) {
		return driver.findElementByXPath(xpathString).getText();
	}

	public List<String> getActualItems() {
		String items = "//android.widget.TextView[contains(@text,'(')]";
		List<AndroidElement> elements = driver.findElements(By.xpath(items));
		List<String> itemsNamesActual = new ArrayList<String>();
		for (AndroidElement androidElement : elements) {
			String text = androidElement.getText();
			itemsNamesActual.add(text);
		}

		System.out.println("itemsNamesActual " + itemsNamesActual);
		return itemsNamesActual;

	}

	public List<String> getExpectedItems(String[] expectedItems) {
		List<String> itemsNamesExpected = new ArrayList<String>();
		for (String item : expectedItems) {
			itemsNamesExpected.add(item);
		}
		return itemsNamesExpected;

	}


	public String getGivenAlbum(String albumName) {
		return "//android.widget.TextView[@text='" + albumName + "']";

	}

	public String getGivenPicture(int picture)
	{


		//return "//androidx.recyclerview.widget.RecyclerView[@resource-id=\"com.oneplus.gallery:id/recyclerview_day\"]/android.widget.RelativeLayout["+ picture +"]/android.widget.Button";
		//System.out.println(picture);

		return "(//android.widget.ImageView[@resource-id=\"com.sec.android.gallery3d:id/thumbnail\"])["+ picture +"]";


	}


	public void openGalleryAndSelectAlbum(String albumName, int picture) throws InterruptedException {

		Thread.sleep(2000);
		String openGalleryLocator = "//android.widget.TextView[@text='From Gallery']";
		clickElement(openGalleryLocator);
		String openFoodAlbum = getGivenAlbum(albumName);
		clickElement(openFoodAlbum);
		String selectFoodPicture = getGivenPicture(picture);
		//String path = "//androidx.recyclerview.widget.RecyclerView[@resource-id=\"com.oneplus.gallery:id/recyclerview_day\"]/android.widget.RelativeLayout[2]/android.widget.Button";
		clickElement(selectFoodPicture);
		Thread.sleep(2000);
	}

	public void selectAlbumOnly(String albumName, int picture) throws InterruptedException {

		Thread.sleep(2000);
		String openFoodAlbum = getGivenAlbum(albumName);
		clickElement(openFoodAlbum);
		String selectFoodPicture = getGivenPicture(picture);
		clickElement(selectFoodPicture);
		Thread.sleep(2000);
	}

	public void  verifyExpectedAndActual(String[] expectedItems) {
		boolean matches = false;
		List<String> itemsNamesActual = getActualItems();

		List<String> itemsNamesExpected = getExpectedItems(expectedItems);
		System.out.println(itemsNamesActual.size()+" "+itemsNamesExpected.size());

		if(itemsNamesExpected.size() > itemsNamesActual.size()) {
			for(String value: itemsNamesExpected) {
				System.out.println(itemsNamesActual.size());
				if (itemsNamesActual.contains(value)) {
					matches = true;
					break;
				}
			}
		}else {
			for(String value: itemsNamesActual) {
				if (itemsNamesExpected.contains(value)) {
					matches = true;
					break;
				}
			}
		}

		if (itemsNamesExpected.size() == itemsNamesActual.size()) {

			matches = itemsNamesActual.equals(itemsNamesExpected);
		}

		if (itemsNamesActual.size() <= 0) {
			String noItemsSorry = "//android.view.ViewGroup//android.view.ViewGroup//android.widget.TextView[contains(@text,'Sorry')]";
			String message = getText(noItemsSorry);
			System.out.println("The expected Items are " + itemsNamesExpected + " however we got this **** " + message
					+ "  ****   ");
			assertTrue(false);
		} else if (!matches) {
			System.out.println(
					"The items doesnt match, Expected " + itemsNamesExpected + " however got this " + itemsNamesActual);

			assertTrue(false);

		} else {
			System.out.println(
					"The items matched, Expected " + itemsNamesExpected + " and actual items " + itemsNamesActual);
			assertTrue(true);
		}

	}

	public void addToDairy() throws InterruptedException {
		Thread.sleep(7000);
		System.out.println("Add to Dairy");
		String addToDairy = "//android.widget.TextView[@text='Add to Diary']";
		clickElement(addToDairy);
		Thread.sleep(7000);

	}

	//Side Angle
	@Test
	public void TestCaseA1bread() throws InterruptedException {
		openGalleryAndSelectAlbum("Pics",8 );
		//selectAlbumOnly("Pics", 1);
		String[] expectedItems = { "Bread (50 grams)" };
		verifyExpectedAndActual(expectedItems);

		addToDairy();
		driver.closeApp();

	}
	//Testing watermelon bottom angle
	@Test
	public void TestCaseA2watermelon() throws InterruptedException {
		openGalleryAndSelectAlbum("Pics", 6);
		//selectAlbumOnly("Pics", 1);
		String[] expectedItems = { "Watermelon (50 ml)" };
		verifyExpectedAndActual(expectedItems);

		addToDairy();
		driver.closeApp();

	}

	//spaghetti top angle
	@Test
	public void TestCaseA3spaghetti() throws InterruptedException {
		openGalleryAndSelectAlbum("Pictures", 1);
		//selectAlbumOnly("Pics", 1);
		String[] expectedItems = { "Spaghetti (0.10 cup)", "Meat sauce (200 grams)", "Parmesan cheese (1 slice)", "Basil (50 grams)" };
		verifyExpectedAndActual(expectedItems);

		addToDairy();
		driver.closeApp();

	}

	//Dim light eggs
	@Test
	public void TestCaseA4eggsdimlight() throws InterruptedException {
		openGalleryAndSelectAlbum("Pics", 3);
		//selectAlbumOnly("Pics", 1);
		String[] expectedItems = { "Eggs (50 grams)" };
		verifyExpectedAndActual(expectedItems);

		addToDairy();
		driver.closeApp();

	}
//macaroni patterneed background
	@Test
	public void TestCaseA5macaronipatternbg() throws InterruptedException {
		openGalleryAndSelectAlbum("Pics", 4);
		//selectAlbumOnly("Pics", 1);
		String[] expectedItems = { "Macaroni salad (0.10 cup)" };
		verifyExpectedAndActual(expectedItems);

		addToDairy();
		driver.closeApp();

	}
//french fries indoor lighting
	@Test
	public void TestCaseA6friesIndoor() throws InterruptedException {
		openGalleryAndSelectAlbum("Pics", 5);
		//selectAlbumOnly("Pics", 1);
		String[] expectedItems = { "French fries (50 grams)" };
		verifyExpectedAndActual(expectedItems);

		addToDairy();
		driver.closeApp();

	}
//cake in dark light
	@Test
	public void TestCaseA7CakeDark() throws InterruptedException {
		openGalleryAndSelectAlbum("Pics", 1);
		//selectAlbumOnly("Pics", 1);
		String[] expectedItems = { "Strawberry cake (20 grams)" };
		verifyExpectedAndActual(expectedItems);

		addToDairy();
		driver.closeApp();

	}
//asian noodles side angle
	@Test
	public void TestCaseA8Noodles() throws InterruptedException {
		openGalleryAndSelectAlbum("Pics", 2);
		//selectAlbumOnly("Pics", 1);
		String[] expectedItems = {"Asian noodles (0.10 cup)"};
		verifyExpectedAndActual(expectedItems);

		addToDairy();
		driver.closeApp();

	}


}


